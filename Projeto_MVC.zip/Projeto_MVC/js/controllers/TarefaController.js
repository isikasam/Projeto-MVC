/**
* O Controller é o "chefe".
* Ele recebe ordens da View e manda o Model agir.
* Ele é o intermediário que conecta as duas partes.
*/
export class TarefaController {
constructor(model, view) {
this.model = model; // Conecta com o banco de dados (Model)
this.view = view; // Conecta com a tela (View)
// Assim que o site abre, ele já manda a View mostrar o que tem no Model
this.view.renderizar(this.model.tarefas);
}
/**
* Função que decide o que acontece quando alguém quer adicionar uma tarefa.
* @param {string} texto - O texto da tarefa a ser adicionada.
*/
adicionarTarefa(texto) {
if (texto.trim() !== "") {
this.model.adicionar(texto); // 1. Manda o Model guardar o dado
this.view.renderizar(this.model.tarefas); // 2. Manda a View atualizar a tela
}
}
}