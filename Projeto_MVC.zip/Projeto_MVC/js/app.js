/**
* Este arquivo é o "interruptor" que liga o projeto inteiro.
* Ele é o ponto de entrada (entry point) da aplicação.
*/
import { TarefaModel } from './models/TarefaModel.js';
import { TarefaView } from './views/TarefaView.js';
import { TarefaController } from './controllers/TarefaController.js';
// Criamos as instâncias (objetos) de cada parte
const model = new TarefaModel();
const view = new TarefaView();
const controller = new TarefaController(model, view);
// Fica "vigiando" o botão de adicionar no HTML
document.querySelector('#btn-adicionar').addEventListener('click', () => {
// Pega o valor do input
const input = document.querySelector('#tarefa-input');
const texto = input.value;
// Quando clicado, ele avisa o Controller para agir
controller.adicionarTarefa(texto);
});
// Também permite adicionar ao pressionar "Enter" no input
document.querySelector('#tarefa-input').addEventListener('keypress', (e) => {
if (e.key === 'Enter') {
const texto = e.target.value;
controller.adicionarTarefa(texto);
}
});
const botaoTema = document.getElementById("tema-btn");

botaoTema.addEventListener("click", () => {
    document.body.classList.toggle("dark");

    if (document.body.classList.contains("dark")) {
        botaoTema.textContent = " Modo Claro";
    } else {
        botaoTema.textContent = "Modo Escuro";
    }
});
document.getElementById("contador").textContent =
`Total de tarefas: ${tarefas.length}`;
this.container.innerHTML = tarefas.map(t =>
`
<li>
    <input type="checkbox">
    ${t}
</li>
`
).join('');

