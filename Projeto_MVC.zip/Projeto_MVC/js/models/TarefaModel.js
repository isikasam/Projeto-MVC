/**
* O Model é onde os dados "moram".
* Ele não sabe nada de HTML ou botões.
* Sua única responsabilidade é gerenciar os dados e a lógica de negócio.
*/
export class TarefaModel {
constructor() {
// Nossa lista de informações (o "estoque" do restaurante)
this.tarefas = ["Estudar HTML", "Aprender CSS", "Programar em JavaScript"];
}
/**
* Função para mexer nos dados.
* @param {string} novaTarefa - O texto da nova tarefa a ser adicionada.
*/
adicionar(novaTarefa) {
if (novaTarefa.trim() !== "") {
this.tarefas.push(novaTarefa); // Adiciona um novo item ao array
}
}
}