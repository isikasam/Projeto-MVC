/**
* A View é responsável apenas por "desenhar" as coisas na tela.
* Ela não deve conter lógica de negócio, apenas lógica de apresentação.
*/
export class TarefaView {
constructor() {
// Ela guarda a referência de onde a lista vai aparecer no HTML
this.container = document.querySelector('#lista-container');
// Referência para o campo de entrada para limpá-lo após adicionar
this.input = document.querySelector('#tarefa-input');
}
/**
* Essa função recebe a lista e transforma em HTML visível.
* @param {string[]} tarefas - Array de strings contendo as tarefas.
*/
renderizar(tarefas) {
// O .map percorre a lista e o .join transforma em um texto só
this.container.innerHTML = tarefas.map(t => `<li>${t}</li>`).join('');
// Limpa o campo de entrada após renderizar (opcional, mas bom para UX)
if (this.input) {
this.input.value = '';
this.input.focus();
}
}
}
this.container.innerHTML = tarefas.map(t =>
`
<li>
    <span>${t}</span>
    <div class="icones">
        ✏️ 🗑️
    </div>
</li>
`
).join('');
